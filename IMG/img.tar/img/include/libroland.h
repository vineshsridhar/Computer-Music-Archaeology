/*
**	Defines for Roland products (except MPU, see libmpu.h)
**	psl 3/90
*/
#define d define
#d ID_ROLAND	0x41		/*$ Roland manufacturer MIDI id # */
#undef d
