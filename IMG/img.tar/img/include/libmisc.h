#define d define
#d Case break; case
#d Default break; default
#d Int register int
#d Char register char
static char *__arg, *__argp; /* use by 'for_each_argument */
static char *av0;	/* will hold the name of the command */
#d argument  (__arg=(*__argp? __argp : av[++i==ac? --i : i]),__argp+=strlen(__argp), __arg)
#d for_each_argument av0 = av[0]; for (i=1;i<ac && *av[i]=='-';i++)\
			for (__argp = &av[i][1]; *__argp;)\
				switch(*__argp++)
#ifndef Alloc
#define Alloc(x) (x *)malloc(sizeof(x))
#endif
#d loop(i,j) for(i=0;i<j;i++)
#d Type typedef struct
#ifndef u_char
#define u_char	unsigned char
#define u_short unsigned short
#endif
#ifdef	FILE
FILE *sopen(), *OpenTune();
#endif
#d TOGGLE(X)		((X)^=1)
#d INRANGE(L,X,H)	((L)<=(X)&&(X)<=(H))
