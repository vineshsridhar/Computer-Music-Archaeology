#include <stdio.h>

MidiError(fmt,arg)
	char *fmt;
/*
** fprintf(stderr,fmt,arg)
*/
{
	_doprnt(fmt, &arg, stderr);
}

MidiExit(code,fmt,arg)
	char *fmt;
{
	_doprnt(fmt,arg,stderr);
	exit(code);
}
